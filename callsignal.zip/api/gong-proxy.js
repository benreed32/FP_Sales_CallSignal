// api/gong-proxy.js
// Vercel serverless function - proxies requests to Gong API
// This is required because Gong blocks direct browser requests (CORS)

export default async function handler(req, res) {
  // Allow requests from your Vercel domain
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  // Handle preflight
  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { path, body, authorization } = req.body;

  if (!path || !authorization) {
    return res.status(400).json({ error: 'Missing path or authorization' });
  }

  // Only allow Gong API endpoints
  if (!path.startsWith('/v2/')) {
    return res.status(403).json({ error: 'Only Gong v2 API paths are allowed' });
  }

  try {
    const response = await fetch(`https://api.gong.io${path}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': authorization,
      },
      body: JSON.stringify(body),
    });

    const data = await response.json();
    return res.status(response.status).json(data);
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
}
